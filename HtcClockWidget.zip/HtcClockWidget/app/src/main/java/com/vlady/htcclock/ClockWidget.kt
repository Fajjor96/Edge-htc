package com.vlady.htcclock

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.AlarmClock
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

// MODIFICA QUI la tua città
const val CITY = "ROMA"
const val LAT = 41.9028
const val LON = 12.4964

/** Impostazioni di aspetto del widget (salvate dalla schermata delle impostazioni). */
object ClockPrefs {
    fun sp(c: Context) = c.getSharedPreferences("clockset", Context.MODE_PRIVATE)
    fun timeSp(c: Context) = sp(c).getInt("time", 56)
    fun ampmSp(c: Context) = sp(c).getInt("ampm", 12)
    fun dateSp(c: Context) = sp(c).getInt("date", 24)
    fun infoSp(c: Context) = sp(c).getInt("info", 11)
    fun iconDp(c: Context) = sp(c).getInt("icon", 26)
    fun gapDp(c: Context) = sp(c).getInt("gap", 28)
    fun lineGapDp(c: Context) = sp(c).getInt("linegap", 2)
    fun fontTime(c: Context) = sp(c).getInt("font_time", 0)
    fun fontDate(c: Context) = sp(c).getInt("font_date", 2)
}

class ClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        render(context)
        schedule(context)
    }

    override fun onEnabled(context: Context) {
        schedule(context)
        WorkManager.getInstance(context)
            .enqueue(OneTimeWorkRequestBuilder<WeatherWorker>().build())
    }

    private fun schedule(context: Context) {
        val req = PeriodicWorkRequestBuilder<WeatherWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork("weather", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    companion object {
        fun render(context: Context) {
            val wp = context.getSharedPreferences("w", Context.MODE_PRIVATE)
            val views = RemoteViews(context.packageName, R.layout.widget)
            val density = context.resources.displayMetrics.density

            // Dati meteo
            views.setTextViewText(R.id.w_city, CITY)
            views.setTextViewText(
                R.id.w_temp,
                if (wp.contains("temp")) "${wp.getInt("temp", 0)}°C" else "--°C"
            )

            // Icona meteo HTC, ridimensionata alla misura scelta
            val name = "ic_w_%02d".format(wp.getInt("code", 1))
            val res = context.resources.getIdentifier(name, "drawable", context.packageName)
            if (res != 0) {
                val bmp = BitmapFactory.decodeResource(context.resources, res)
                if (bmp != null) {
                    val h = (ClockPrefs.iconDp(context) * density).toInt().coerceAtLeast(8)
                    val w = (bmp.width * h / bmp.height).coerceAtLeast(8)
                    views.setImageViewBitmap(R.id.w_icon, Bitmap.createScaledBitmap(bmp, w, h, true))
                }
            }

            // Font e dimensioni
            val timeIds = intArrayOf(R.id.time0, R.id.time1, R.id.time2, R.id.time3)
            val dateIds = intArrayOf(R.id.date0, R.id.date1, R.id.date2, R.id.date3)
            val ft = ClockPrefs.fontTime(context).coerceIn(0, 3)
            val fd = ClockPrefs.fontDate(context).coerceIn(0, 3)
            for (i in 0..3) {
                views.setViewVisibility(timeIds[i], if (i == ft) View.VISIBLE else View.GONE)
                views.setTextViewTextSize(timeIds[i], TypedValue.COMPLEX_UNIT_SP, ClockPrefs.timeSp(context).toFloat())
                views.setViewVisibility(dateIds[i], if (i == fd) View.VISIBLE else View.GONE)
                views.setTextViewTextSize(dateIds[i], TypedValue.COMPLEX_UNIT_SP, ClockPrefs.dateSp(context).toFloat())
            }
            views.setTextViewTextSize(R.id.ampm, TypedValue.COMPLEX_UNIT_SP, ClockPrefs.ampmSp(context).toFloat())
            val info = ClockPrefs.infoSp(context).toFloat()
            views.setTextViewTextSize(R.id.w_city, TypedValue.COMPLEX_UNIT_SP, info)
            views.setTextViewTextSize(R.id.w_day, TypedValue.COMPLEX_UNIT_SP, info)
            views.setTextViewTextSize(R.id.w_temp, TypedValue.COMPLEX_UNIT_SP, info)

            // Distanze
            views.setViewPadding(R.id.date_area, (ClockPrefs.gapDp(context) * density).toInt(), 0, 0, 0)
            views.setViewPadding(R.id.info_row, 0, (ClockPrefs.lineGapDp(context) * density).toInt(), 0, 0)

            // Tocco su ora (e spazi vuoti): app Orologio
            val clockIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(
                context, 0, clockIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.root, pi)
            views.setOnClickPendingIntent(R.id.clock_area, pi)

            // Tocco su data e meteo: Calendario
            val calIntent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val calPi = PendingIntent.getActivity(
                context, 1, calIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.date_area, calPi)

            val mgr = AppWidgetManager.getInstance(context)
            mgr.updateAppWidget(ComponentName(context, ClockWidget::class.java), views)
        }
    }
}
