package com.vlady.htcclock

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.URL
import kotlin.math.roundToInt

class WeatherWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        return try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,weather_code,is_day"
            val cur = JSONObject(URL(url).readText()).getJSONObject("current")
            val temp = cur.getDouble("temperature_2m").roundToInt()
            val day = cur.getInt("is_day") == 1
            val code = htcIcon(cur.getInt("weather_code"), day)
            ctx.getSharedPreferences("w", Context.MODE_PRIVATE).edit()
                .putInt("temp", temp).putInt("code", code).apply()
            ClockWidget.render(ctx)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    // Codici icona stile HTC (01 sole, 02/03 poco nuvoloso, 07 nuvoloso, 11 nebbia,
    // 12 pioggia leggera, 15 temporale, 18 pioggia, 19 nevischio, 22 neve, 26 pioggia gelata,
    // 33/34/35 notte sereno/poco nuvoloso)
    private fun htcIcon(wmo: Int, day: Boolean): Int = when (wmo) {
        0 -> if (day) 1 else 33
        1 -> if (day) 2 else 34
        2 -> if (day) 3 else 35
        3 -> 7
        45, 48 -> 11
        51, 53, 55, 56, 57, 80, 81, 82 -> 12
        61, 63, 65 -> 18
        66, 67 -> 26
        71, 73, 75, 77 -> 22
        85, 86 -> 19
        95, 96, 99 -> 15
        else -> 7
    }
}
