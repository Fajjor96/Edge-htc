package com.vlady.htcedge

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

/** Elenco di app (e interruttori) tra cui scegliere cosa mettere nell'anello. */
class PickerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ring = intent.getIntExtra("ring", 0)
        title = if (ring == 0) "Anello interno" else "Anello esterno"

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val specials = listOf(
            Pair("Torcia", "special:torch"),
            Pair("Internet", "special:wifi"),
            Pair("Bluetooth", "special:bluetooth"),
            Pair("Sveglie e timer", "special:alarm")
        )
        val all = specials + apps

        val lv = ListView(this)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, all.map { it.first })

        val selected = Prefs.ring(this, ring).toMutableList()
        for ((i, p) in all.withIndex()) lv.setItemChecked(i, selected.contains(p.second))

        lv.setOnItemClickListener { _, _, pos, _ ->
            val id = all[pos].second
            if (lv.isItemChecked(pos)) {
                if (!selected.contains(id)) selected.add(id)
            } else {
                selected.remove(id)
            }
            Prefs.setRing(this, ring, selected)
        }
        setContentView(lv)
    }
}
