package com.vlady.htcedge

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.cos
import kotlin.math.sin

/**
 * Menu ad arco sul bordo destro, nello stile dell'HTC Quick Launcher:
 * disco e anello bianchi al 10%, icone in anelli bianchi sottili,
 * anello azzurro (#03B4D3) sull'icona toccata.
 */
class ArcMenu(ctx: Context, entries: List<Entry>, onOutside: () -> Unit) : FrameLayout(ctx) {

    class Entry(val icon: Drawable, val label: String, val action: () -> Unit)

    private val d = resources.displayMetrics.density
    private val itemRadiusDp = floatArrayOf(100f, 168f)
    private val discRadiusDp = 135f
    private val outerRingRadiusDp = 200f
    private val cyan = 0xFF03B4D3.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val rings: List<List<View>>
    private val all: List<View>
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cx = 0f
    private var cy = 0f

    init {
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = 0x1AFFFFFF
        ringPaint.style = Paint.Style.STROKE
        ringPaint.strokeWidth = 1.5f * d
        ringPaint.color = 0x33FFFFFF
        setBackgroundColor(0x66000000)
        setWillNotDraw(false)
        setOnClickListener { onOutside() }

        val size = (44 * d).toInt()
        val views = entries.map { makeItem(it) }
        for (v in views) addView(v, LayoutParams(size, size))
        all = views
        rings = listOf(views.take(5), views.drop(5))
    }

    private fun circle(color: Int, widthDp: Float): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(0x55000000)
        g.setStroke((widthDp * d).toInt(), color)
        return g
    }

    private fun makeItem(e: Entry): View {
        val v = ImageView(context)
        v.background = circle(white, 1.5f)
        val p = (7 * d).toInt()
        v.setPadding(p, p, p, p)
        v.setImageDrawable(e.icon)
        v.contentDescription = e.label
        v.setOnClickListener { e.action() }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.background = circle(cyan, 2.5f)
                    view.animate().scaleX(1.15f).scaleY(1.15f).setDuration(80).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.background = circle(white, 1.5f)
                    view.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                }
            }
            false
        }
        return v
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE) {
            for ((i, v) in all.withIndex()) {
                v.alpha = 0f
                v.scaleX = 0.5f
                v.scaleY = 0.5f
                v.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .setStartDelay(i * 25L).setDuration(180).start()
            }
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        cx = w.toFloat()
        cy = h * 0.6f
        val half = 22 * d
        for ((ri, ring) in rings.withIndex()) {
            val radius = itemRadiusDp[minOf(ri, itemRadiusDp.size - 1)] * d
            val k = ring.size
            for ((i, v) in ring.withIndex()) {
                val deg = if (k == 1) 0.0 else -75.0 + 150.0 * i / (k - 1)
                val a = Math.toRadians(deg)
                val x = cx - radius * cos(a).toFloat()
                val y = cy + radius * sin(a).toFloat()
                v.layout((x - half).toInt(), (y - half).toInt(), (x + half).toInt(), (y + half).toInt())
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawCircle(cx, cy, discRadiusDp * d, fillPaint)
        canvas.drawCircle(cx, cy, outerRingRadiusDp * d, ringPaint)
    }
}
