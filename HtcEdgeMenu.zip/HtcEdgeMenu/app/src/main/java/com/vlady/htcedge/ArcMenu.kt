package com.vlady.htcedge

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Menu nello stile dell'HTC Quick Launcher: calendario in alto, due anelli di icone
 * sul bordo destro che ruotano in cerchio con il dito, ingranaggio impostazioni in basso.
 */
class ArcMenu(
    ctx: Context,
    inner: List<Entry>,
    outer: List<Entry>,
    showCalendar: Boolean,
    private val iconDp: Int,
    private val centerYPct: Int,
    private val scalePct: Int,
    private val host: Host
) : FrameLayout(ctx) {

    class Entry(
        val icon: Drawable,
        val label: String,
        val plate: Boolean,
        val isActive: (() -> Boolean)? = null,
        val action: () -> Unit
    )

    interface Host {
        fun launch(i: Intent)
        fun close()
    }

    private class Ring(val views: List<View>, val step: Float, val visible: Int) {
        var offset = 0f
    }

    private val d = resources.displayMetrics.density
    private val cyan = 0xFF03B4D3.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val rings: List<Ring>
    private val itemEntries = ArrayList<Pair<ImageView, Entry>>()

    private var cx = 0f
    private var cy = 0f
    private var innerR = 0f
    private var outerR = 0f
    private var discR = 0f
    private var bigR = 0f
    private var reveal = 1f
    private var revealAnim: ValueAnimator? = null
    private var snapAnim: ValueAnimator? = null
    private var activeRing = -1
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var lastAngle = 0f

    init {
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = 0x1FFFFFFF
        ringPaint.style = Paint.Style.STROKE
        ringPaint.strokeWidth = 1.5f * d
        ringPaint.color = 0x4DFFFFFF
        setBackgroundColor(0xE6000000.toInt())
        setWillNotDraw(false)

        if (showCalendar) {
            val cal = MiniCalendar(
                context,
                { ms ->
                    host.launch(Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time/$ms")))
                },
                {
                    host.launch(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR))
                }
            )
            val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP)
            lp.topMargin = (56 * d).toInt()
            lp.leftMargin = (12 * d).toInt()
            lp.rightMargin = (12 * d).toInt()
            addView(cal, lp)
        }

        val size = (iconDp * d).toInt()
        val innerViews = inner.map { makeItem(it) }
        val outerViews = outer.map { makeItem(it) }
        for (v in innerViews + outerViews) addView(v, LayoutParams(size, size))
        rings = listOf(Ring(innerViews, 26f, 5), Ring(outerViews, 21f, 6))

        val gear = ImageView(context)
        gear.setImageResource(R.drawable.ic_settings)
        gear.background = circle(white, 1.5f, 0)
        val gp = (10 * d).toInt()
        gear.setPadding(gp, gp, gp, gp)
        gear.setOnClickListener { host.launch(Intent(context, MainActivity::class.java)) }
        val glp = LayoutParams((44 * d).toInt(), (44 * d).toInt(), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        glp.bottomMargin = (48 * d).toInt()
        addView(gear, glp)
    }

    private fun circle(strokeColor: Int, widthDp: Float, fill: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(fill)
        if (widthDp > 0f) g.setStroke((widthDp * d).toInt(), strokeColor)
        return g
    }

    private fun makeItem(e: Entry): View {
        val v = ImageView(context)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        if (e.plate) {
            val p = (iconDp * 0.22f * d).toInt()
            v.setPadding(p, p, p, p)
            applyActive(v, e)
        }
        v.setImageDrawable(e.icon)
        v.contentDescription = e.label
        itemEntries.add(Pair(v, e))
        v.setOnClickListener {
            e.action()
            v.postDelayed({ applyActive(v, e) }, 250)
        }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.foreground = circle(cyan, 2.5f, 0)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.foreground = null
                }
            }
            false
        }
        return v
    }

    // Le icone-interruttore (torcia, Wi-Fi, Bluetooth) diventano azzurre quando sono attive.
    private fun applyActive(v: ImageView, e: Entry) {
        if (!e.plate) return
        val on = try {
            e.isActive?.invoke() == true
        } catch (ex: Exception) {
            false
        }
        v.background = circle(0, 0f, if (on) cyan else 0xFF5B5B60.toInt())
    }

    fun refreshActive() {
        for ((v, e) in itemEntries) applyActive(v, e)
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) refreshActive()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val wf = w.toFloat()
        cx = wf * 1.03f
        cy = h * centerYPct / 100f
        val sc = scalePct / 100f
        innerR = wf * 0.28f * sc
        outerR = wf * 0.48f * sc
        discR = wf * 0.375f * sc
        bigR = wf * 0.55f * sc
        updatePositions()
    }

    private fun updatePositions() {
        if (width == 0) return
        val half = iconDp * d / 2f
        for ((ri, ring) in rings.withIndex()) {
            val n = ring.views.size
            if (n == 0) continue
            val radius = (if (ri == 0) innerR else outerR) * (0.6f + 0.4f * reveal)
            val limit = ring.visible * ring.step / 2f
            val cycle = max(n, ring.visible) * ring.step
            for ((i, v) in ring.views.withIndex()) {
                var a = (i - (n - 1) / 2f) * ring.step + ring.offset
                a = ((a + cycle / 2f) % cycle + cycle) % cycle - cycle / 2f
                val vis = ((limit - abs(a)) / (ring.step * 0.5f)).coerceIn(0f, 1f) * reveal
                val rad = Math.toRadians(a.toDouble())
                val x = cx - radius * cos(rad).toFloat()
                val y = cy + radius * sin(rad).toFloat()
                v.translationX = x - half
                v.translationY = y - half
                v.alpha = vis
                val sc = 0.7f + 0.3f * vis
                v.scaleX = sc
                v.scaleY = sc
                v.visibility = if (vis <= 0.01f) View.INVISIBLE else View.VISIBLE
            }
        }
        invalidate()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE) {
            revealAnim?.cancel()
            val a = ValueAnimator.ofFloat(0f, 1f)
            a.duration = 220
            a.addUpdateListener {
                reveal = it.animatedValue as Float
                updatePositions()
            }
            a.start()
            revealAnim = a
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawCircle(cx, cy, discR, fillPaint)
        canvas.drawCircle(cx, cy, bigR, ringPaint)
    }

    private fun ringAt(x: Float, y: Float): Int {
        val dist = hypot(x - cx, y - cy)
        return when {
            dist > bigR -> -1
            dist < (innerR + outerR) / 2f -> 0
            else -> 1
        }
    }

    private fun angleOf(x: Float, y: Float): Float =
        Math.toDegrees(atan2((y - cy).toDouble(), (cx - x).toDouble())).toFloat()

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                dragging = false
                activeRing = ringAt(ev.x, ev.y)
                lastAngle = angleOf(ev.x, ev.y)
                snapAnim?.cancel()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && activeRing >= 0 && hypot(ev.x - downX, ev.y - downY) > slop) {
                    dragging = true
                    lastAngle = angleOf(ev.x, ev.y)
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                dragging = false
                activeRing = ringAt(ev.x, ev.y)
                lastAngle = angleOf(ev.x, ev.y)
                snapAnim?.cancel()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && activeRing >= 0 && hypot(ev.x - downX, ev.y - downY) > slop) {
                    dragging = true
                    lastAngle = angleOf(ev.x, ev.y)
                }
                if (dragging && activeRing >= 0) {
                    val a = angleOf(ev.x, ev.y)
                    var delta = a - lastAngle
                    if (delta > 180f) delta -= 360f
                    if (delta < -180f) delta += 360f
                    rings[activeRing].offset += delta
                    lastAngle = a
                    updatePositions()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    snapRing(activeRing)
                } else {
                    host.close()
                }
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) snapRing(activeRing)
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(ev)
    }

    private fun snapRing(i: Int) {
        if (i < 0) return
        val ring = rings[i]
        val target = (ring.offset / ring.step).roundToInt() * ring.step
        snapAnim?.cancel()
        val a = ValueAnimator.ofFloat(ring.offset, target)
        a.duration = 160
        a.addUpdateListener {
            ring.offset = it.animatedValue as Float
            updatePositions()
        }
        a.start()
        snapAnim = a
    }
}
