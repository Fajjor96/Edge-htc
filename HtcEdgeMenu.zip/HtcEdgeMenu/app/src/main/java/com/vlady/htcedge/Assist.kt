package com.vlady.htcedge

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.view.View

class AssistService : VoiceInteractionService()

class AssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = HtcAssistSession(this)
}

// Richiesto da Android per elencare l'app tra gli assistenti; non fa riconoscimento vocale.
class StubRecognizer : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try {
            listener?.error(SpeechRecognizer.ERROR_CLIENT)
        } catch (e: Exception) {
        }
    }

    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}

class HtcAssistSession(ctx: Context) : VoiceInteractionSession(ctx) {

    override fun onCreateContentView(): View = buildMenu()

    private fun buildMenu(): View {
        val pm = context.packageManager
        val entries = mutableListOf<ArcMenu.Entry>()

        // Modifica qui le app mostrate nel menu (nome pacchetto)
        val pkgs = listOf(
            "com.google.android.apps.maps",
            "com.google.android.gm",
            "com.facebook.katana",
            "com.google.android.youtube",
            "com.android.chrome",
            "com.whatsapp",
            "com.google.android.GoogleCamera",
            "com.google.android.apps.photos"
        )
        for (pkg in pkgs) {
            val intent = pm.getLaunchIntentForPackage(pkg) ?: continue
            val icon = try {
                pm.getApplicationIcon(pkg)
            } catch (e: Exception) {
                continue
            }
            entries.add(ArcMenu.Entry(icon, pkg) { launch(intent) })
        }

        context.getDrawable(R.drawable.ic_torch)?.let {
            entries.add(ArcMenu.Entry(it, "Torcia") { toggleTorch() })
        }
        context.getDrawable(R.drawable.ic_wifi)?.let {
            entries.add(ArcMenu.Entry(it, "Internet") {
                launch(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            })
        }
        context.getDrawable(R.drawable.ic_alarm)?.let {
            entries.add(ArcMenu.Entry(it, "Sveglie e timer") {
                launch(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            })
        }
        return ArcMenu(context, entries) { hide() }
    }

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(i)
        } catch (e: Exception) {
            try {
                startAssistantActivity(i)
            } catch (e2: Exception) {
            }
        }
        hide()
    }

    private fun toggleTorch() {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id != null) {
                torchOn = !torchOn
                cm.setTorchMode(id, torchOn)
            }
        } catch (e: Exception) {
        }
        hide()
    }

    companion object {
        var torchOn = false
    }
}
