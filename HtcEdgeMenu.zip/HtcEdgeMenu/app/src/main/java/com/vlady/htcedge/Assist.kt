package com.vlady.htcedge

import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.FrameLayout

class AssistService : VoiceInteractionService()

class AssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = HtcAssistSession(this)
}

// Richiesto da Android per elencare l'app tra gli assistenti; non fa riconoscimento vocale.
class StubRecognizer : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try {
            listener?.error(SpeechRecognizer.ERROR_CLIENT)
        } catch (e: Exception) {
        }
    }

    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}

class HtcAssistSession(ctx: Context) : VoiceInteractionSession(ctx) {

    private var root: FrameLayout? = null
    private var torchRegistered = false

    private val host = object : ArcMenu.Host {
        override fun launch(i: Intent) {
            this@HtcAssistSession.launch(i)
        }

        override fun close() {
            hide()
        }
    }

    override fun onCreateContentView(): View {
        val r = FrameLayout(context)
        r.addView(buildMenu())
        root = r
        return r
    }

    // Ricostruisce il menu a ogni apertura, così le impostazioni cambiate si vedono subito.
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        root?.let {
            it.removeAllViews()
            it.addView(buildMenu())
        }
    }

    private fun buildMenu(): View {
        ensureTorchCallback()
        val inner = entriesFor(Prefs.ring(context, 0))
        val outer = entriesFor(Prefs.ring(context, 1))
        return ArcMenu(
            context, inner, outer,
            Prefs.calendarOn(context), Prefs.iconDp(context), Prefs.centerY(context),
            Prefs.scale(context), host
        )
    }

    private fun entriesFor(ids: List<String>): List<ArcMenu.Entry> {
        val pm = context.packageManager
        val list = mutableListOf<ArcMenu.Entry>()
        for (id in ids) {
            when (id) {
                "special:torch" -> context.getDrawable(R.drawable.ic_torch)?.let {
                    list.add(ArcMenu.Entry(it, "Torcia", true, { torchOn }) { toggleTorch() })
                }
                "special:wifi" -> context.getDrawable(R.drawable.ic_wifi)?.let {
                    list.add(ArcMenu.Entry(it, "Internet", true, { wifiOn() }) {
                        launch(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                    })
                }
                "special:bluetooth" -> context.getDrawable(R.drawable.ic_bluetooth)?.let {
                    list.add(ArcMenu.Entry(it, "Bluetooth", true, { btOn() }) {
                        launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    })
                }
                "special:alarm" -> context.getDrawable(R.drawable.ic_alarm)?.let {
                    list.add(ArcMenu.Entry(it, "Sveglie e timer", true) {
                        launch(Intent(AlarmClock.ACTION_SHOW_ALARMS))
                    })
                }
                else -> {
                    val intent = pm.getLaunchIntentForPackage(id)
                    if (intent != null) {
                        try {
                            val icon = pm.getApplicationIcon(id)
                            list.add(ArcMenu.Entry(icon, id, false) { launch(intent) })
                        } catch (e: Exception) {
                        }
                    }
                }
            }
        }
        return list
    }

    // Apre un'app e chiude il menu.
    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(i)
        } catch (e: Exception) {
            try {
                startAssistantActivity(i)
            } catch (e2: Exception) {
            }
        }
        hide()
    }

    private fun wifiOn(): Boolean = try {
        (context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) {
        false
    }

    private fun btOn(): Boolean = try {
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true
    } catch (e: Exception) {
        false
    }

    // Tiene allineato lo stato della torcia anche se la accendi/spegni da altrove.
    private fun ensureTorchCallback() {
        if (torchRegistered) return
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    torchOn = enabled
                    (root?.getChildAt(0) as? ArcMenu)?.refreshActive()
                }
            }, null)
            torchRegistered = true
        } catch (e: Exception) {
        }
    }

    // Accende/spegne la torcia senza chiudere il menu.
    private fun toggleTorch() {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id != null) cm.setTorchMode(id, !torchOn)
        } catch (e: Exception) {
        }
    }

    companion object {
        var torchOn = false
    }
}
