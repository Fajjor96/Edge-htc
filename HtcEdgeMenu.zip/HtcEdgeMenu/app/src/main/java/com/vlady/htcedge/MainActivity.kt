package com.vlady.htcedge

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val info = TextView(this)
        info.text = "Menu ad arco (stile HTC Edge Sense).\n\n" +
            "1. Tocca il pulsante e scegli questa app come assistente digitale.\n" +
            "2. In Impostazioni > Sistema > Gesti imposta il tasto di accensione " +
            "tenuto premuto su assistente digitale.\n\n" +
            "Poi tieni premuto il tasto di accensione per aprire il menu."
        info.textSize = 16f
        root.addView(info)

        val btn = Button(this)
        btn.text = "Imposta assistente digitale"
        btn.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        root.addView(btn)
        setContentView(root)
    }
}
