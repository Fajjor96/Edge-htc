package com.vlady.htcedge

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Schermata delle impostazioni del menu ad arco. */
class MainActivity : Activity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(20), dp(20), dp(20))
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        addText(root, "Edge Menu HTC", 22f)
        addText(
            root,
            "Tieni premuto il tasto di accensione per aprire il menu. " +
                "Prima scegli questa app come assistente digitale e, in Impostazioni > Sistema > Gesti, " +
                "imposta il tasto di accensione tenuto premuto su assistente digitale.",
            14f
        )
        addButton(root, "Imposta assistente digitale") {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        addText(root, "App nei cerchi", 18f)
        addButton(root, "App anello interno (consigliate 5)") { openPicker(0) }
        addButton(root, "App anello esterno (consigliate 6)") { openPicker(1) }

        addText(root, "Calendario", 18f)
        val sw = Switch(this)
        sw.text = "Mostra il calendario in alto"
        sw.isChecked = Prefs.calendarOn(this)
        sw.setOnCheckedChangeListener { _, checked ->
            Prefs.sp(this).edit().putBoolean("cal", checked).apply()
        }
        root.addView(sw)
        addButton(root, "Mostra i punti rossi degli eventi") {
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 1)
        }

        addText(root, "Aspetto", 18f)
        addSeek(root, "Dimensione icone", 32, 56, "icon", 40, " dp")
        addSeek(root, "Dimensione dei cerchi", 60, 140, "scale", 100, " %")
        addSeek(root, "Altezza del cerchio", 40, 80, "cy", 62, " %")

        addButton(root, "Ripristina predefiniti") {
            Prefs.sp(this).edit().clear().apply()
            recreate()
        }
    }

    private fun openPicker(ring: Int) {
        val i = Intent(this, PickerActivity::class.java)
        i.putExtra("ring", ring)
        startActivity(i)
    }

    private fun addText(root: LinearLayout, s: String, size: Float) {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setPadding(0, dp(14), 0, dp(4))
        root.addView(t)
    }

    private fun addButton(root: LinearLayout, s: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = s
        b.setOnClickListener { onClick() }
        root.addView(b)
    }

    private fun addSeek(root: LinearLayout, label: String, min: Int, max: Int, key: String, def: Int, unit: String) {
        val cur = Prefs.sp(this).getInt(key, def)
        val lbl = TextView(this)
        lbl.text = "$label: $cur$unit"
        lbl.setPadding(0, dp(8), 0, 0)
        root.addView(lbl)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                lbl.text = "$label: $v$unit"
                Prefs.sp(this@MainActivity).edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sb)
    }
}
