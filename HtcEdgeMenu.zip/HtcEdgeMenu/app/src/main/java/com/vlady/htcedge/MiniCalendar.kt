package com.vlady.htcedge

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.provider.CalendarContract
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Calendario del mese in alto, come nel Quick Launcher HTC. */
class MiniCalendar(
    ctx: Context,
    private val onDay: (Long) -> Unit,
    private val onTitle: () -> Unit
) : LinearLayout(ctx) {

    private val d = resources.displayMetrics.density
    private val red = 0xFFEE5360.toInt()
    private val shown: Calendar = Calendar.getInstance()
    private val titleView = TextView(ctx)
    private val weekRow = LinearLayout(ctx)
    private val grid = LinearLayout(ctx)

    init {
        orientation = VERTICAL
        shown.set(Calendar.DAY_OF_MONTH, 1)
        buildHeader(ctx)
        weekRow.orientation = HORIZONTAL
        grid.orientation = VERTICAL
        addView(weekRow)
        addView(grid)
        render()
    }

    private fun buildHeader(ctx: Context) {
        val row = LinearLayout(ctx)
        row.orientation = HORIZONTAL
        row.gravity = Gravity.CENTER
        row.addView(arrow(ctx, "‹") { shift(-1) })
        titleView.textSize = 17f
        titleView.setTextColor(Color.WHITE)
        titleView.gravity = Gravity.CENTER
        titleView.setOnClickListener { onTitle() }
        row.addView(titleView, LayoutParams((170 * d).toInt(), LayoutParams.WRAP_CONTENT))
        row.addView(arrow(ctx, "›") { shift(1) })
        addView(row)
    }

    private fun arrow(ctx: Context, s: String, f: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = 28f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        val p = (16 * d).toInt()
        t.setPadding(p, 0, p, 0)
        t.setOnClickListener { f() }
        return t
    }

    private fun shift(n: Int) {
        shown.add(Calendar.MONTH, n)
        render()
    }

    private fun weekCell(s: String): TextView {
        val t = TextView(context)
        t.text = s
        t.textSize = 13f
        t.setTextColor(0x88FFFFFF.toInt())
        t.gravity = Gravity.CENTER
        t.layoutParams = LayoutParams(0, (28 * d).toInt(), 1f)
        return t
    }

    private fun dot(color: Int, sizeDp: Int): View {
        val v = View(context)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        v.background = g
        v.layoutParams = FrameLayout.LayoutParams((sizeDp * d).toInt(), (sizeDp * d).toInt(), Gravity.CENTER)
        return v
    }

    private fun dayCell(cur: Calendar, inMonth: Boolean, isToday: Boolean, hasEvent: Boolean): View {
        val cell = FrameLayout(context)
        cell.layoutParams = LayoutParams(0, (36 * d).toInt(), 1f)
        val tv = TextView(context)
        tv.text = cur.get(Calendar.DAY_OF_MONTH).toString()
        tv.textSize = 15f
        tv.gravity = Gravity.CENTER
        tv.setTextColor(if (inMonth) Color.WHITE else 0x44FFFFFF)
        if (isToday) {
            tv.setTextColor(Color.WHITE)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(red)
            tv.background = g
        }
        val s = (30 * d).toInt()
        cell.addView(tv, FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        if (hasEvent) {
            val dv = dot(red, 5)
            dv.translationX = 12 * d
            dv.translationY = -12 * d
            cell.addView(dv)
        }
        val ms = cur.timeInMillis
        cell.setOnClickListener { onDay(ms) }
        return cell
    }

    private fun render() {
        val locale = Locale.getDefault()
        titleView.text = SimpleDateFormat("LLLL yyyy", locale).format(shown.time)
            .replaceFirstChar { it.uppercase() }

        val first = shown.firstDayOfWeek
        weekRow.removeAllViews()
        val names = DateFormatSymbols(locale).shortWeekdays
        for (i in 0 until 7) {
            val idx = (first - 1 + i) % 7 + 1
            weekRow.addView(weekCell(names[idx].replaceFirstChar { it.uppercase() }))
        }

        val start = shown.clone() as Calendar
        start.set(Calendar.HOUR_OF_DAY, 0)
        start.set(Calendar.MINUTE, 0)
        start.set(Calendar.SECOND, 0)
        start.set(Calendar.MILLISECOND, 0)
        val offset = (start.get(Calendar.DAY_OF_WEEK) - first + 7) % 7
        start.add(Calendar.DAY_OF_MONTH, -offset)
        val events = loadEvents(start)
        val today = Calendar.getInstance()
        val month = shown.get(Calendar.MONTH)

        grid.removeAllViews()
        val cur = start.clone() as Calendar
        for (r in 0 until 6) {
            val row = LinearLayout(context)
            row.orientation = HORIZONTAL
            for (c in 0 until 7) {
                val key = cur.get(Calendar.YEAR) * 10000 + cur.get(Calendar.MONTH) * 100 + cur.get(Calendar.DAY_OF_MONTH)
                val isToday = cur.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                    cur.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)
                row.addView(dayCell(cur, cur.get(Calendar.MONTH) == month, isToday, events.contains(key)))
                cur.add(Calendar.DAY_OF_MONTH, 1)
            }
            grid.addView(row)
        }
    }

    private fun loadEvents(start: Calendar): Set<Int> {
        val out = HashSet<Int>()
        try {
            if (context.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                return out
            }
            val begin = start.timeInMillis
            val end = begin + 42L * 24L * 3600L * 1000L
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, begin)
            ContentUris.appendId(b, end)
            val c = context.contentResolver.query(
                b.build(), arrayOf(CalendarContract.Instances.BEGIN), null, null, null
            )
            if (c != null) {
                val t = Calendar.getInstance()
                while (c.moveToNext()) {
                    t.timeInMillis = c.getLong(0)
                    out.add(t.get(Calendar.YEAR) * 10000 + t.get(Calendar.MONTH) * 100 + t.get(Calendar.DAY_OF_MONTH))
                }
                c.close()
            }
        } catch (e: Exception) {
        }
        return out
    }
}
