package com.vlady.htcedge

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "edge"

    // Predefiniti: stessa disposizione dell'HTC (5 nell'anello interno, 6 nell'esterno)
    private val DEF0 = listOf(
        "com.google.android.gm",
        "com.google.android.calculator",
        "special:wifi",
        "special:torch",
        "com.google.android.apps.docs"
    )
    private val DEF1 = listOf(
        "com.google.android.apps.messaging",
        "com.facebook.katana",
        "com.google.android.GoogleCamera",
        "com.google.android.apps.maps",
        "com.android.chrome",
        "com.google.android.youtube"
    )

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun ring(c: Context, i: Int): List<String> {
        val s = sp(c).getString("ring$i", null) ?: return if (i == 0) DEF0 else DEF1
        return s.split(",").filter { it.isNotBlank() }
    }

    fun setRing(c: Context, i: Int, list: List<String>) {
        sp(c).edit().putString("ring$i", list.joinToString(",")).apply()
    }

    fun calendarOn(c: Context): Boolean = sp(c).getBoolean("cal", true)
    fun iconDp(c: Context): Int = sp(c).getInt("icon", 40)
    fun centerY(c: Context): Int = sp(c).getInt("cy", 62)
    fun scale(c: Context): Int = sp(c).getInt("scale", 100)
}
